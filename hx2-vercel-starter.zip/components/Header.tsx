export default function Header() {
  return (
    <header className="border-b border-white/10">
      <div className="container py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="size-8 rounded-2xl bg-white/10" />
          <span className="font-semibold">HX2</span>
        </div>
        <nav className="text-sm flex gap-4">
          <a className="hover:underline" href="/">Home</a>
          <a className="hover:underline" href="/api/health">Health</a>
        </nav>
      </div>
    </header>
  );
}