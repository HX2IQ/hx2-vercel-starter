export type AppConfig = {
  H2_MODE: string | undefined;
  WWDD_DEFAULT: string | undefined;
  OPENAI_API_KEY?: string | undefined;
};
export function getConfig(): AppConfig {
  return {
    H2_MODE: process.env.H2_MODE,
    WWDD_DEFAULT: process.env.WWDD_DEFAULT,
    OPENAI_API_KEY: process.env.OPENAI_API_KEY
  };
}