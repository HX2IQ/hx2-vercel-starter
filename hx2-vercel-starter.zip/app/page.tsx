import { getHX2Status } from "@/lib/hx2";
import { getConfig } from "@/lib/config";

export default function Home() {
  const cfg = getConfig();
  const status = getHX2Status(cfg);

  return (
    <section className="card p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">HX2 Starter</h1>
        <span className="badge">WWDD: {cfg.WWDD_DEFAULT?.toUpperCase() || "OFF"}</span>
      </div>
      <p className="text-sm text-white/70">
        Deploy scaffold for HX2/AP2 on Vercel. Tailwind is configured, env loader in place, and a health route is live.
      </p>
    </section>
  );
}