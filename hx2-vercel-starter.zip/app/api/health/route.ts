import { NextResponse } from "next/server";
import { getConfig } from "@/lib/config";
export const runtime = "edge";
export async function GET() {
  const cfg = getConfig();
  return NextResponse.json({
    ok: true,
    service: "hx2",
    wwdd: cfg.WWDD_DEFAULT || "off",
    time: new Date().toISOString()
  });
}